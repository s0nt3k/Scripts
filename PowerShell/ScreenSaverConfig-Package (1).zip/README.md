# Windows Screen Saver Registry Configuration Generator — console edition

Run `ScreenSaverConfig.ps1` from a writable folder as the Windows user whose screen saver you want to configure. The intended runtime is 64-bit Windows PowerShell 5.1 or PowerShell 7 on Windows 10/11.

```powershell
.\ScreenSaverConfig.ps1
```

The menu contains exactly:

1. None
2. 3D Text
3. Blank
4. Rubbles
5. Mystify
6. Photos
7. Ribbons

“Rubbles” selects the installed Windows **Bubbles** saver. `-ScreenSaver Bubbles` also works. Pictures has been removed as a screen saver choice; Pictures remains available as the default Photos folder.

## Console configuration

**No native screen saver Settings dialogs open.** Generating files does not temporarily save any screen saver settings to the registry. Only the optional folder-selection browser uses a separate window.

**Photos:** select the default `%USERPROFILE%\Pictures` folder, type a directory, browse for one, or select an immediate Pictures subdirectory. Then choose **Slow, Medium or Fast** and whether to **shuffle pictures**. The directory is validated, converted to a Windows Shell folder identifier, Base64 encoded into `EncryptedPIDL`, and checked against the requested path. The identifier is rebuilt on every run, so changing the directory does not require a prior native capture. `EncryptedPIDL` is the legacy value name; the generated data is an encoded folder identifier, not password encryption.

**3D Text:** choose custom text or current time, then configure font family, font height, weight, italic, character set, font pitch/family, size, resolution/mesh quality, rotation speed/type, surface type, shine, custom color, texture, reflection/environment image, and matching animation across monitors. Text is limited to 20 characters. File paths must exist. Colors accept `#RRGGBB`.

**Bubbles:** glass appearance, shadows, desktop background, radius, density, turbulence force/speed/octaves, spanning monitors and matching animations.

**Mystify:** number of lines, line width, blur/trails and monitor options.

**Ribbons:** number of ribbons, width, blur/trails and monitor options.

**None and Blank:** no saver-specific visual options.

Each visual-setting prompt displays the current override or “Windows default.” Press **Enter** to preserve it; type **DEFAULT** to remove its override. Existing settings are read and retained unless changed. Signed font heights, colors and floating-point settings are converted to their registry representation automatically. Some 3D Text choices expose native numeric codes rather than assuming a label-to-code mapping for every Windows build.

For each configurable saver, an additional console editor lets you set any build-specific value under the saver's allowed registry roots, including per-monitor subkeys. It asks for the name, type and value. This also allows a stored option not covered by the named prompts to be configured without opening Regedit.

**Advanced-effect limitation:** Windows does not publish a stable configuration contract for all Bubbles, Mystify, Ribbons or 3D Text internals. Listed advanced values, numeric codes and ranges are an editing interface, not a guarantee that every Windows build honors every setting. Unspecified values use Windows defaults. Check the result on your target build before wider deployment.

## Wait time and power checks

The full wizard asks for screen saver wait time and whether to show the logon screen on resume. It examines display-off, ordinary sleep and hibernation timers for both AC (plugged in) and DC (battery). A nonzero timer at or before screen saver activation triggers a console choice to disable that timer, enter new minutes or keep it with a warning.

The script displays a summary, asks before generating files, then asks separately before applying them. It does not launch the saver. Hibernation idle behavior depends on sleep state and hardware; its conflict check is conservative. Unreadable or unavailable timers are reported, and explicit requests to change them fail clearly.

## Configuration files and unattended operation

```powershell
# Generate a new starter JSON without overwriting an existing file:
.\ScreenSaverConfig.ps1 -Setup -SetupPath .\MySettings.json

# Use an edited configuration:
.\ScreenSaverConfig.ps1 -Configuration .\MySettings.json

# Reopen console visual-option prompts for an existing configuration:
.\ScreenSaverConfig.ps1 -Configuration .\MySettings.json -ConfigureOptions

# Generate without prompts; do not apply:
.\ScreenSaverConfig.ps1 -Configuration .\MySettings.json -NonInteractive

# Generate and apply with explicit opt-in:
.\ScreenSaverConfig.ps1 -Configuration .\MySettings.json -NonInteractive -Apply
```

`-Setup` alone creates `ScreenSaverConfig.default.json`; the download already includes that file, so use `-SetupPath` for a different filename if it exists. Each generated session also saves its complete reusable `*.Configuration.json`.

Parameters override JSON; JSON overrides defaults. The starter selects None. JSON booleans must be `true`/`false`, not strings. `null` power values preserve existing timers; `0` means Never. A noninteractive timer conflict causes a clear failure rather than silently changing the power plan.

Photos works without a previous capture in unattended mode:

```powershell
.\ScreenSaverConfig.ps1 -ScreenSaver Photos `
    -PhotosDirectory 'C:\Company Photos' -PhotoSpeed Fast -PhotoShuffle $true `
    -WaitMinutes 5 -RequireLogon $true `
    -DisplayACMinutes 20 -DisplayDCMinutes 10 `
    -SleepACMinutes 30 -SleepDCMinutes 15 `
    -HibernateACMinutes 60 -HibernateDCMinutes 30 -NonInteractive
```

Pass boolean examples from a PowerShell prompt. For scheduled tasks or launching from another shell, prefer JSON to avoid shell-specific Boolean conversion.

| Parameter | Purpose |
|---|---|
| `-Setup`, `-SetupPath` | Create a new starter JSON |
| `-Configuration` | Load JSON settings |
| `-ScreenSaver` | None, 3D Text, Blank, Rubbles/Bubbles, Mystify, Photos, Ribbons |
| `-WaitMinutes` | Integer 1–9999; default 10 |
| `-RequireLogon` | Boolean; default true |
| `-TextMode` | Custom or Time |
| `-Message` | Custom 3D text; maximum 20 characters |
| `-PhotosDirectory` | Existing readable photo folder |
| `-PhotoSpeed` | Slow, Medium or Fast |
| `-PhotoShuffle` | Boolean |
| `-SaverValuesJson` | File containing a typed registry-value array |
| `-DisplayACMinutes`, `-DisplayDCMinutes` | Display-off idle timers; 0 = Never |
| `-SleepACMinutes`, `-SleepDCMinutes` | Ordinary sleep idle timers; 0 = Never |
| `-HibernateACMinutes`, `-HibernateDCMinutes` | Hibernation idle timers; 0 = Never |
| `-ConfigureOptions` | Show console visual-option prompts when loading a configuration |
| `-NonInteractive` | No prompts; generate only unless `-Apply` is supplied |
| `-Apply` | Explicit application request |

`-NativeSettings` has been removed. Old `PhotosCapturedDirectory` fields are accepted but ignored. Old configurations selecting Pictures must be changed to Photos.

## All other options through parameters/JSON

Console-entered options are saved in `SaverValues`. Edit that array in the session configuration, or put the array in a separate JSON file and pass `-SaverValuesJson .\VisualOptions.json`.

```json
[
  {
    "Path": "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Screensavers\\ssText3d",
    "Name": "FontFace",
    "Kind": "String",
    "Value": "Arial"
  }
]
```

Kinds: `String`, `ExpandString`, `DWord`, `QWord`, `Binary`, `MultiString`, `Delete`. Binary values use Base64; MultiString uses a string array. DWORDs in JSON are numeric; the additional console editor also accepts `0xHEX`. Floating-point advanced options store IEEE-754 single-precision bits in a DWORD. Only the selected saver's allowlisted HKCU option roots are accepted.

Direct text/time/message and Photos folder/speed/shuffle choices take precedence over equivalent raw entries. This keeps a stale folder value from overriding the directory you just selected.

## Files, reports and application

```text
<ScriptFolder>\RegFiles\<COMPUTERNAME>\
    <session>.ScreenSaver.reg
    <session>.ScreenSaver.Restore.reg
    <session>.Power.reg
    <session>.Power.Restore.reg
    <session>.Configuration.json
<ScriptFolder>\Logs\<COMPUTERNAME>\<session>.jsonl
<ScriptFolder>\Reports\<COMPUTERNAME>\<session>.html
```

Sessions use unique timestamped filenames. Registry exports are commented UTF-16LE files. Restore files restore affected values observed before generation; newly introduced values are removed. Power restores reproduce effective prior timer values, including inherited values. Empty registry keys may remain.

HTML reports include requested settings, before/after power readings, generated files and activity. JSON Lines logs record prompts, choices, commands and errors. Setup, cancellation and failures after initialization also produce reports. Parameter-binding errors or unwritable output folders may occur before logging can start.

On application, saver files are imported using `reg.exe`; power changes use Microsoft's supported `powercfg` interface, followed by plan activation and verification. Direct power-registry imports can leave cached settings stale, so generated files explain plan reactivation. Session refresh uses `SystemParametersInfo`; sign out/in if refresh fails.

Power changes require an elevated PowerShell session under the **same Windows user**. If rights are missing, files are generated but no settings are applied. The script does not elevate itself or switch accounts. SYSTEM and 32-bit PowerShell on 64-bit Windows are rejected. Import/apply/verification errors trigger an attempted rollback and are recorded.

Managed policy, Modern Standby, hibernation availability, critical-battery actions and application power requests can affect real activation. The script does not enable hibernation, change lid/power-button or critical-battery behavior, or override domain/MDM policy. Restore files belong to their originating machine, user and power plan.

For the optional folder browser, run an STA session:

```powershell
powershell.exe -NoProfile -STA -File .\ScreenSaverConfig.ps1
# Or on Windows:
pwsh.exe -NoProfile -STA -File .\ScreenSaverConfig.ps1
```

## Verification

Passed PowerShell parser checks, registry escaping/encoding tests, numeric boundaries, deletion and wrapped-binary checks, allowlisted path checks, option conversion round trips, numeric validation, all 19 3D Text option prompts, and C# Shell interop compilation. A console-flow test with mocked Windows interfaces verified Photos speed/shuffle prompts, Fast/no-shuffle registry output, generation/application confirmations, logging and HTML reporting.

**Live Windows testing was not available.** The actual Shell folder conversion, Windows PowerShell 5.1 execution, saver rendering, registry imports and power changes still need testing on the target computer. The mock tests do not establish Windows runtime compatibility.

## Microsoft references

- [Configure a screen saver](https://support.microsoft.com/en-us/windows/configure-a-screen-saver-in-windows-a9dc2a0c-dc8e-9161-d270-aaccc252082a)
- [SHParseDisplayName](https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shparsedisplayname)
- [ILGetSize](https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-ilgetsize)
- [SHGetPathFromIDListW](https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shgetpathfromidlistw)
- [Powercfg options](https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options)
- [SystemParametersInfoW](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow)
