# Windows Screen Saver Registry Configuration Generator

Save `ScreenSaverConfig.ps1` to a writable folder and run it as the Windows user whose screen saver you want to configure. Supports 64-bit Windows PowerShell 5.1 and PowerShell 7 on Windows 10/11, subject to the installed screen savers and hardware power features.

## Start the interactive wizard

```powershell
.\ScreenSaverConfig.ps1
```

For a folder-selection window, use an STA session. Windows PowerShell normally uses STA already:

```powershell
powershell.exe -NoProfile -STA -File .\ScreenSaverConfig.ps1
# Or, with PowerShell 7 on Windows:
pwsh.exe -NoProfile -STA -File .\ScreenSaverConfig.ps1
```

The wizard selects a saver, configures its options, asks for the wait and resume-logon settings, checks power timers, presents a summary, asks before generation, and asks separately before application. It does not launch the screen saver itself.

**Pictures and Photos:** modern Windows provides Photos. Both choices use that installed saver. The script does not install the old Windows XP “My Pictures Slideshow.” Missing saver executables produce a clear error.

**Saver-specific options:** 3D Text and Photos use Windows' own Settings dialogs, exposing the options supported by the installed version. For 3D Text, choose custom text or time first; that choice and message take precedence over the native dialog's text/time fields. The other native dialog choices are captured as typed registry values. Blank has no options. Bubbles, Mystify and Ribbons do not expose supported Settings controls on current Windows. Existing advanced values can be captured, or supplied through `-SaverValuesJson`; undocumented tweaks are not represented as guaranteed working features.

**Photos folders:** choose `%USERPROFILE%\Pictures`, type an existing directory, use the folder browser, or select an immediate Pictures subdirectory. Typed paths expand Windows environment variables and are checked for existence, directory type, filesystem provider and readable enumeration. A redirected Pictures folder can be selected through the custom or browse option.

Windows stores the Photos folder selection as an opaque `EncryptedPIDL` value. On the first Photos run, the script shows the validated requested path, opens native Photos Settings, and asks you to select that same folder using Browse and Save. It then asks you to confirm the selection. It cannot independently decode and verify the opaque folder value. Folder path, speed and shuffle are saved with the captured settings for unattended reuse. Changing the directory requires a fresh native capture. Folder selections are local-machine/user snapshots; configure again when moving to another computer or user.

**Native-dialog capture temporarily saves its options to the current user's registry.** Before opening the dialog, the script saves a recovery JSON snapshot; afterward a `finally` block restores the previous keys. The screen saver's activation, wait and resume settings are not applied during capture. Do not configure the same saver in another application during this operation. Avoid killing PowerShell during capture: abrupt termination can bypass restoration. The recovery JSON records the original roots, key names and typed values if manual recovery becomes necessary.

## Default configuration and reuse

```powershell
# Creates a new starter file; refuses to overwrite an existing one:
.\ScreenSaverConfig.ps1 -Setup

# Or choose a new filename:
.\ScreenSaverConfig.ps1 -Setup -SetupPath .\MyScreenSaver.json

# Edit the JSON, then generate files with confirmation:
.\ScreenSaverConfig.ps1 -Configuration .\MyScreenSaver.json

# Generate without prompts; does not apply:
.\ScreenSaverConfig.ps1 -Configuration .\MyScreenSaver.json -NonInteractive

# Generate and apply without prompts (explicit opt-in):
.\ScreenSaverConfig.ps1 -Configuration .\MyScreenSaver.json -NonInteractive -Apply
```

A starter JSON is included in the download. `-Setup` generates the same defaults; use another filename if the included default file already exists.

Each completed generation also saves a session-specific `*.Configuration.json`. Reuse that file to reproduce the captured font, appearance, Photos selection, or advanced values. The starter selects None; change `ScreenSaver` to activate a saver. `SchemaVersion` must remain `1`. JSON booleans must be `true`/`false`, not strings. Power values are integer minutes; `null` preserves the current setting and `0` means Never.

Without `-NonInteractive`, a configuration-file or direct-parameter run still asks about power conflicts, file generation and application. It does not repeat the complete type-selection wizard. Use `-NativeSettings` to recapture native options when using a configuration file or direct parameters. This switch is interactive only.

## Parameters

Explicit parameters override the JSON. Unspecified values use the JSON, then defaults.

| Parameter | Values or purpose |
|---|---|
| `-Setup` | Generate starter JSON and finish; does not inspect or change Windows settings |
| `-SetupPath` | Output filename for `-Setup` |
| `-Configuration` | Read a JSON configuration file |
| `-ScreenSaver` | `None`, `3D Text`, `Blank`, `Pictures`, `Bubbles`, `Mystify`, `Photos`, `Ribbons` |
| `-WaitMinutes` | Integer 1–9999; default 10 |
| `-RequireLogon` | Boolean; default `$true` |
| `-TextMode` | `Custom` or `Time` |
| `-Message` | Custom 3D text, maximum 20 characters |
| `-PhotosDirectory` | Existing readable folder; first selection or change requires native capture |
| `-PhotoSpeed` | `Slow`, `Medium`, `Fast` |
| `-PhotoShuffle` | Boolean |
| `-SaverValuesJson` | JSON array of typed saver-specific registry values; replaces `SaverValues` from configuration |
| `-DisplayACMinutes`, `-DisplayDCMinutes` | Display-off idle timer; 0 = Never |
| `-SleepACMinutes`, `-SleepDCMinutes` | Ordinary sleep idle timer; 0 = Never |
| `-HibernateACMinutes`, `-HibernateDCMinutes` | Hibernate idle timer; 0 = Never |
| `-NativeSettings` | Open native dialog and capture its values |
| `-NonInteractive` | No prompts; missing Photos capture or a timer conflict fails clearly |
| `-Apply` | Explicitly request application after generation |

AC means plugged in; DC means running on battery. Both plan values are examined even on a desktop without a battery. For None, no timer conflicts are raised because the saver is disabled. Timers at the same time as the saver are flagged too. Hibernate idle timing can depend on sleep state and hardware; its comparison is conservative.

```powershell
# Current time in 3D Text; generate only, without prompts:
.\ScreenSaverConfig.ps1 -ScreenSaver '3D Text' -TextMode Time `
    -WaitMinutes 5 -RequireLogon $true `
    -DisplayACMinutes 20 -DisplayDCMinutes 10 `
    -SleepACMinutes 30 -SleepDCMinutes 15 `
    -HibernateACMinutes 60 -HibernateDCMinutes 30 -NonInteractive

# Bubbles, with all three ordinary idle timers disabled for both power sources:
.\ScreenSaverConfig.ps1 -ScreenSaver Bubbles -WaitMinutes 10 `
    -RequireLogon $true -DisplayACMinutes 0 -DisplayDCMinutes 0 `
    -SleepACMinutes 0 -SleepDCMinutes 0 `
    -HibernateACMinutes 0 -HibernateDCMinutes 0 -NonInteractive

# Start Photos configuration and native capture:
.\ScreenSaverConfig.ps1 -ScreenSaver Photos -PhotosDirectory 'C:\Company Photos' `
    -WaitMinutes 5 -NativeSettings
```

Pass boolean examples from a PowerShell prompt, as shown. For scheduled tasks or another shell's `-File` invocation, prefer JSON so boolean argument conversion does not depend on the launching shell.

## Every saver-specific setting through JSON/parameters

Native capture saves **all values under the selected saver's known option keys**, retaining registry types. Change `SaverValues` in the session configuration, or put that array alone in a separate file and pass `-SaverValuesJson .\SaverValues.json`. This is the parameter route for font, size, rotation, surface style, texture, reflection and any captured advanced values; the script does not guess their version-specific numeric ranges.

Example structure (use a captured configuration as your starting point):

```json
[
  {
    "Path": "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Screensavers\\ssText3d",
    "Name": "FontFace",
    "Kind": "String",
    "Value": "Arial"
  }
]
```

Supported kinds: `String`, `ExpandString`, `DWord`, `QWord`, `MultiString`, `Binary` and `Delete`. Binary values are Base64 strings; MultiString values are JSON arrays. Names, type values and paths are validated before export. Values may only target that selected saver's allowlisted HKCU option roots. Direct text/time and Photos speed/shuffle selections take precedence over corresponding raw entries. Unsupported numeric settings may be ignored or behave differently across Windows versions.

## Output and recovery

Every session has a unique timestamp plus random suffix to avoid overwriting another session.

```text
<ScriptFolder>\RegFiles\<COMPUTERNAME>\
    <session>.ScreenSaver.reg
    <session>.ScreenSaver.Restore.reg
    <session>.Power.reg
    <session>.Power.Restore.reg
    <session>.Configuration.json
    <session>.NativeDialogRecovery.json   (when native capture is used)
<ScriptFolder>\Logs\<COMPUTERNAME>\<session>.jsonl
<ScriptFolder>\Reports\<COMPUTERNAME>\<session>.html
```

Registry exports contain explanatory comments and use UTF-16LE with a BOM. Restore exports restore affected values to their pre-generation state; newly introduced values are removed. Empty registry keys may remain. Power restore files restore the prior **effective values**, even when an original value was inherited rather than explicitly stored.

The HTML report includes the final configuration, power readings before/after application, generated filenames, prompts, decisions, warnings and errors. The JSON Lines log records time-stamped activity and command output. Reports are also attempted for setup, cancellation and failures reached after initialization. Parameter-binding errors and unwritable output directories can prevent logging before the session starts.

**Application:** saver settings are imported with `reg.exe`. Power settings are applied with Microsoft's supported `powercfg` interface, then the plan is reactivated and values verified. Direct imports alone can leave Windows' power cache stale, so the power `.reg` file includes a plan-reactivation instruction. Session refresh uses `SystemParametersInfo`; sign out/in if refresh is unsuccessful.

Changing power settings requires an elevated PowerShell session **under the same Windows user**. When required rights are missing, files are generated but no configuration is applied. The script does not elevate itself or switch accounts. SYSTEM and 32-bit PowerShell on 64-bit Windows are rejected.

If importing/applying/verifying fails, the script attempts to restore saver values and original power timers, and records rollback errors. For manual recovery, review/import the matching Restore files and run the `powercfg /setactive <plan GUID>` command shown in the power restore file. Restore exports belong to the machine, user and plan where they were generated.

Hardware sleep capabilities, Modern Standby, hibernation availability, critical-battery actions, application power requests and managed policy can affect actual activation. Unavailable/unreadable idle timers are reported; explicit requests to change those timers fail rather than pretending success. Managed screen saver policy is reported when its registry key is present and is not changed. The script does not enable hibernation, change lid/power-button actions, alter critical-battery behavior, or override domain/MDM policy.

## Verification performed

Parsed with the PowerShell 7.4 parser. Executed `-Setup`, including JSON generation, logging and HTML reporting. Checked registry string escaping, signed/unsigned DWORD boundaries, deletions, wrapped binary round trips, UTF-16LE output, allowlisted path boundaries, overrides, and language-independent extraction of power timer indices using fixture output.

**Windows runtime testing was not available in the build environment.** Native dialogs, real registry import, PowerShell 5.1 execution, powercfg changes, rollback against live Windows settings and screen saver activation still need testing on the target PC before broader deployment. Review the report and test a short wait interval on that PC.

## Microsoft references

- [Configure a screen saver in Windows](https://support.microsoft.com/en-us/windows/configure-a-screen-saver-in-windows-a9dc2a0c-dc8e-9161-d270-aaccc252082a)
- [SCRNSAVE.EXE registry behavior](https://learn.microsoft.com/en-us/windows/win32/devnotes/scrnsave-exe)
- [Powercfg command-line options](https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options)
- [SystemParametersInfoW](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-systemparametersinfow)
