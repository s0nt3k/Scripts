#Requires -Version 5.1
<#
.SYNOPSIS
Windows Screen Saver Registry Configuration Generator.
.DESCRIPTION
Interactive wizard or JSON/parameter-driven generation. Does not apply generated
files without confirmation or -Apply. Native saver dialogs temporarily change only
the selected saver's settings; those keys are backed up and restored in finally.
Run as the intended signed-in user, in 64-bit Windows PowerShell 5.1 or PowerShell 7.
.EXAMPLE
.\ScreenSaverConfig.ps1
.EXAMPLE
.\ScreenSaverConfig.ps1 -Setup
.EXAMPLE
.\ScreenSaverConfig.ps1 -Configuration .\ScreenSaverConfig.default.json
.EXAMPLE
.\ScreenSaverConfig.ps1 -ScreenSaver '3D Text' -TextMode Time -WaitMinutes 5 -RequireLogon $true -DisplayACMinutes 20 -DisplayDCMinutes 10 -SleepACMinutes 30 -SleepDCMinutes 15 -HibernateACMinutes 60 -HibernateDCMinutes 30 -NonInteractive
.EXAMPLE
.\ScreenSaverConfig.ps1 -Configuration .\saved.json -NonInteractive -Apply
.NOTES
Photos folder encoding is captured using Windows' own Photos Settings dialog.
For unattended Photos runs, first save a configured session and reuse its JSON.
Pictures is an alias of Photos on modern Windows. No legacy XP slideshow is installed.
Power .reg files are snapshots of the active plan's backing registry; Windows'
supported powercfg API is also used on apply to activate and verify each change.
Importing a power .reg alone may need plan reactivation or a restart.
#>
[CmdletBinding()]
param(
    [switch]$Setup,
    [string]$Configuration,
    [string]$SetupPath,
    [ValidateSet('None','3D Text','Blank','Pictures','Bubbles','Mystify','Photos','Ribbons')][string]$ScreenSaver,
    [ValidateRange(1,9999)][int]$WaitMinutes,
    [bool]$RequireLogon,
    [ValidateSet('Custom','Time')][string]$TextMode,
    [ValidateLength(0,20)][string]$Message,
    [string]$PhotosDirectory,
    [ValidateSet('Slow','Medium','Fast')][string]$PhotoSpeed,
    [bool]$PhotoShuffle,
    # Typed registry-value array: [{Path,Name,Kind,Value}]. See README and saved JSON.
    [string]$SaverValuesJson,
    [ValidateRange(0,35791394)][int]$DisplayACMinutes,
    [ValidateRange(0,35791394)][int]$DisplayDCMinutes,
    [ValidateRange(0,35791394)][int]$SleepACMinutes,
    [ValidateRange(0,35791394)][int]$SleepDCMinutes,
    [ValidateRange(0,35791394)][int]$HibernateACMinutes,
    [ValidateRange(0,35791394)][int]$HibernateDCMinutes,
    [switch]$NativeSettings,
    [switch]$NonInteractive,
    [switch]$Apply
)
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
$bound = @{}; foreach ($k in $PSBoundParameters.Keys) { $bound[$k] = $PSBoundParameters[$k] }
$session = (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
if (-not $PSScriptRoot) { throw 'Save this script to a .ps1 file before running it.' }
$hostNameSafe = if ($env:COMPUTERNAME) { $env:COMPUTERNAME } else { 'UnknownHost' }
$dirs = @{}; foreach ($d in 'RegFiles','Logs','Reports') {
    $dirs[$d] = Join-Path (Join-Path $PSScriptRoot $d) $hostNameSafe
    New-Item -ItemType Directory -Path $dirs[$d] -Force | Out-Null
}
$logPath = Join-Path $dirs.Logs "$session.jsonl"
$events = New-Object 'System.Collections.Generic.List[object]'
$files = New-Object 'System.Collections.Generic.List[string]'
$status = 'Started'; $cfg = $null; $powerBefore = @(); $powerAfter = @(); $scheme = $null
function Log([string]$Text,[string]$Level='Info') {
    $row = [pscustomobject]@{Time=(Get-Date).ToString('o');Level=$Level;Message=$Text}
    $events.Add($row); $row | ConvertTo-Json -Compress -Depth 12 | Add-Content -LiteralPath $logPath -Encoding UTF8
    Write-Host "[$Level] $Text"
}
function Ask([string]$Prompt,[string]$Default='') {
    if ($NonInteractive) { throw "Prompt required in noninteractive mode: $Prompt" }
    $v = Read-Host "$Prompt$(if ($Default -ne '') { " [$Default]" })"
    if ([string]::IsNullOrWhiteSpace($v)) { $v = $Default }
    Log "$Prompt => $v" 'Input'; return $v
}
function Yes([string]$Prompt,[bool]$Default=$true) {
    while ($true) {
        $v = Ask "$Prompt (Y/N)" $(if($Default){'Y'}else{'N'})
        if ($v -match '^(y|yes)$') { return $true }; if ($v -match '^(n|no)$') { return $false }
        Write-Host 'Enter Y or N.'
    }
}
function Minutes([string]$Prompt,[int]$Default,[int]$Minimum=0) {
    while ($true) { $s = Ask $Prompt ([string]$Default); $n=0
        if ([int]::TryParse($s,[ref]$n) -and $n -ge $Minimum -and $n -le 35791394) { return $n }
        Write-Host "Enter a whole number from $Minimum to 35791394. Zero means Never for power timers."
    }
}
function Choose([string]$Prompt,[string[]]$Items) {
    for ($i=0;$i -lt $Items.Count;$i++) { Write-Host (' {0}. {1}' -f ($i+1),$Items[$i]) }
    while($true) { $v=Ask $Prompt '1'; $n=0
        if([int]::TryParse($v,[ref]$n) -and $n -ge 1 -and $n -le $Items.Count){return $Items[$n-1]}
        Write-Host 'Select a listed number.'
    }
}
function Run-Power([string[]]$Arguments) {
    $out = & "$env:SystemRoot\System32\powercfg.exe" @Arguments 2>&1 | Out-String
    Log "powercfg $($Arguments -join ' ')`n$out"
    if ($LASTEXITCODE -ne 0) { throw "powercfg failed ($LASTEXITCODE): $out" }; return $out
}
function Escape-Reg([string]$s) { return $s.Replace('\','\\').Replace('"','\"') }
function Reg-Line($r) {
    if ($r.Name -match '[\r\n\x00]') { throw 'Registry names cannot contain control characters.' }
    $name = if($r.Name -eq ''){'@'}else{'"'+(Escape-Reg $r.Name)+'"'}
    if ($r.Kind -eq 'Delete') { return "$name=-" }
    $bytes = $null
    switch ($r.Kind) {
        'String' {
            if ([string]$r.Value -match '[\r\n\x00]') {
                $bytes=[Text.Encoding]::Unicode.GetBytes(([string]$r.Value)+[char]0); $prefix='hex(1):'
            } else { return $name+'="'+(Escape-Reg ([string]$r.Value))+'"' }
        }
        'DWord' {
            $n=[long]$r.Value; if($n -lt [int]::MinValue -or $n -gt [uint32]::MaxValue){throw 'DWord outside 32-bit range.'}
            $u = if($n -lt 0){[uint32]($n+4294967296)}else{[uint32]$n}
            return $name+'=dword:'+$u.ToString('x8')
        }
        'QWord' { $bytes=[BitConverter]::GetBytes([long]$r.Value); $prefix='hex(b):' }
        'Binary' { $bytes=[Convert]::FromBase64String([string]$r.Value); $prefix='hex:' }
        'ExpandString' { $bytes=[Text.Encoding]::Unicode.GetBytes(([string]$r.Value)+[char]0); $prefix='hex(2):' }
        'MultiString' { $bytes=[Text.Encoding]::Unicode.GetBytes((@($r.Value) -join [char]0)+[char]0+[char]0); $prefix='hex(7):' }
        default { throw "Unsupported registry type $($r.Kind)" }
    }
    # Wrap hexadecimal values to produce importable, reviewable .reg files.
    $hex=@($bytes | ForEach-Object {$_.ToString('x2')})
    $chunks=New-Object 'System.Collections.Generic.List[string]'
    for($i=0;$i -lt $hex.Count;$i+=24){$end=[Math]::Min($i+23,$hex.Count-1);$chunks.Add(($hex[$i..$end] -join ','))}
    return $name+'='+$prefix+($chunks -join ",\`r`n  ")
}
function Write-Reg([string]$Path,[object[]]$Rows,[string[]]$Comments) {
    $lines=New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('Windows Registry Editor Version 5.00'); $lines.Add('')
    foreach($c in $Comments){foreach($line in ($c -split '\r?\n')){$lines.Add('; '+$line)}}
    foreach($group in ($Rows | Group-Object Path)) {
        $lines.Add(''); $lines.Add('['+$group.Name+']')
        foreach($r in $group.Group){$lines.Add((Reg-Line $r))}
    }
    [IO.File]::WriteAllText($Path,($lines -join "`r`n")+"`r`n",[Text.Encoding]::Unicode)
    $files.Add($Path); Log "Generated $Path"
}
function Row([string]$Path,[string]$Name,[string]$Kind,$Value) {
    [pscustomobject]@{Path=$Path;Name=$Name;Kind=$Kind;Value=$Value}
}
function Snapshot([string]$Root) {
    $keys=New-Object 'System.Collections.Generic.List[string]'
    $values=New-Object 'System.Collections.Generic.List[object]'
    function Visit([string]$Sub) {
        $key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($Sub)
        if($null -eq $key){return}
        try {
            $keys.Add($Sub)
            foreach($n in $key.GetValueNames()){
                $kind=$key.GetValueKind($n).ToString()
                $v=$key.GetValue($n,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                if($kind -eq 'Binary'){$v=[Convert]::ToBase64String($v)}
                $values.Add((Row "HKEY_CURRENT_USER\$Sub" $n $kind $v))
            }
            foreach($child in $key.GetSubKeyNames()){ Visit "$Sub\$child" }
        } finally {$key.Dispose()}
    }
    Visit $Root
    return [pscustomobject]@{Root=$Root;Keys=@($keys.ToArray());Values=@($values.ToArray())}
}
function Restore-Snapshot($s) {
    [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($s.Root,$false)
    foreach($k in $s.Keys){$key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($k);$key.Dispose()}
    foreach($r in $s.Values){
        $sub=$r.Path.Substring('HKEY_CURRENT_USER\'.Length)
        $key=[Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($sub)
        try {
            $v=$r.Value
            switch($r.Kind){
                'Binary'{$v=[Convert]::FromBase64String($v)}
                'DWord'{$v=[int]$v}
                'QWord'{$v=[long]$v}
                'MultiString'{$v=[string[]]$v}
            }
            $key.SetValue($r.Name,$v,[Microsoft.Win32.RegistryValueKind]$r.Kind)
        }finally{$key.Dispose()}
    }
}
function Validate-Folder([string]$Path) {
    $expanded=[Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
    $item=Get-Item -LiteralPath $expanded -ErrorAction Stop
    if(-not $item.PSIsContainer -or $item.PSProvider.Name -ne 'FileSystem'){throw 'Choose an existing filesystem directory.'}
    Get-ChildItem -LiteralPath $item.FullName -ErrorAction Stop | Select-Object -First 1 | Out-Null
    return $item.FullName
}
function Select-PhotosFolder {
    $default=Join-Path $env:USERPROFILE 'Pictures'
    while($true){
        $choice=Choose 'Choose the photo folder method' @('Default: %USERPROFILE%\Pictures','Type a directory','Browse for a directory','Select a Pictures subdirectory')
        try{
            switch -Wildcard ($choice){
                'Default:*' {return (Validate-Folder $default)}
                'Type*' {return (Validate-Folder (Ask 'Existing photo directory'))}
                'Browse*' {
                    if([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA'){throw 'Folder browsing requires STA. Run powershell.exe -STA -File .\ScreenSaverConfig.ps1 (or pwsh -STA).'}
                    Add-Type -AssemblyName System.Windows.Forms
                    $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
                    try{$dialog.Description='Select the screen saver photos directory';$dialog.ShowNewFolderButton=$false
                        if($dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK){return (Validate-Folder $dialog.SelectedPath)}
                    }finally{$dialog.Dispose()}
                }
                'Select*' {
                    $children=@(Get-ChildItem -LiteralPath $default -Directory -ErrorAction Stop | Sort-Object Name)
                    if($children.Count -eq 0){throw 'Pictures has no immediate subdirectories.'}
                    return (Validate-Folder (Choose 'Choose a subdirectory' @($children.FullName)))
                }
            }
        }catch{Log $_.Exception.Message 'Warning'}
    }
}
function Native-Capture([string]$Executable,[string[]]$Roots) {
    $snaps=@(foreach($root in $Roots){Snapshot $root})
    $recovery=Join-Path $dirs.RegFiles "$session.NativeDialogRecovery.json"
    $snaps | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $recovery -Encoding UTF8
    Log "Native dialog recovery snapshot: $recovery. Do not edit this saver's settings elsewhere during capture."
    $captured=@()
    try {
        # Windows UI exposes the available options for this exact installed saver.
        $p=Start-Process -FilePath $Executable -ArgumentList '/c' -PassThru
        $p.WaitForExit()
        foreach($root in $Roots){$captured+=@((Snapshot $root).Values)}
    }finally{
        foreach($snap in $snaps){Restore-Snapshot $snap}
        Log 'Restored pre-dialog screen saver option keys.'
    }
    return $captured
}
function Check-Values([object[]]$Rows,[string[]]$Roots) {
    foreach($r in $Rows){
        if($null -eq $r -or -not ($r.PSObject.Properties.Name -contains 'Path') -or -not ($r.PSObject.Properties.Name -contains 'Name') -or -not ($r.PSObject.Properties.Name -contains 'Kind') -or -not ($r.PSObject.Properties.Name -contains 'Value')){throw 'Each SaverValues entry requires Path, Name, Kind, Value.'}
        $ok=$false
        foreach($root in $Roots){$prefix="HKEY_CURRENT_USER\$root";if($r.Path -eq $prefix -or $r.Path.StartsWith($prefix+'\',[StringComparison]::OrdinalIgnoreCase)){$ok=$true}}
        if(-not $ok -or $r.Path -match '[\[\]\r\n\x00]'){throw "SaverValues path is outside the selected saver's allowed keys: $($r.Path)"}
        $null=Reg-Line $r
    }
}
function Upsert([object[]]$Rows,$New) {
    return @($Rows | Where-Object {-not ($_.Path -eq $New.Path -and $_.Name -eq $New.Name)})+@($New)
}
function Read-Setting([string]$Sub,[string]$Setting) {
    $text=Run-Power @('/query',$scheme,$Sub,$Setting)
    # /query's last two hexadecimal indices are AC and DC, independent of UI language.
    $hits=[regex]::Matches($text,'0x([0-9a-fA-F]{8})')
    if($hits.Count -lt 2){throw "Cannot read AC/DC indices for $Setting."}
    return @{AC=[Convert]::ToUInt32($hits[$hits.Count-2].Groups[1].Value,16);DC=[Convert]::ToUInt32($hits[$hits.Count-1].Groups[1].Value,16)}
}
function Prior-Row($r) {
    $key=Get-Item -LiteralPath ('Registry::'+$r.Path) -ErrorAction SilentlyContinue
    if($null -eq $key){return (Row $r.Path $r.Name 'Delete' $null)}
    try {
        if($key.GetValueNames() -notcontains $r.Name){return (Row $r.Path $r.Name 'Delete' $null)}
        $v=$key.GetValue($r.Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        $kind=$key.GetValueKind($r.Name).ToString();if($kind -eq 'Binary'){$v=[Convert]::ToBase64String($v)}
        return (Row $r.Path $r.Name $kind $v)
    }finally{$key.Dispose()}
}
function Import-Reg([string]$Path) {
    $out=& "$env:SystemRoot\System32\reg.exe" import $Path 2>&1 | Out-String
    Log "reg import $Path`n$out";if($LASTEXITCODE -ne 0){throw "Registry import failed: $Path"}
}
function Write-Report {
    $encode={param($x) [Net.WebUtility]::HtmlEncode([string]$x)}
    $html="<!doctype html><html><head><meta charset='utf-8'><title>Screen Saver Configuration Session</title><style>body{font:15px Segoe UI,Arial;margin:36px;color:#172a3a}h1{color:#155e75}pre{white-space:pre-wrap;background:#f0f5f8;padding:16px}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #ccd7df;text-align:left;vertical-align:top}.Warning,.Error{color:#a32a20}</style></head><body><h1>Windows Screen Saver Registry Configuration Generator</h1>"
    $html+='<p>Session: '+(& $encode $session)+' | Computer: '+(& $encode $hostNameSafe)+' | User: '+(& $encode "$env:USERDOMAIN\$env:USERNAME")+' | Status: '+(& $encode $status)+'</p>'
    $html+='<h2>Requested configuration</h2><pre>'+(& $encode ($cfg | ConvertTo-Json -Depth 30))+'</pre>'
    $html+='<h2>Power state before</h2><pre>'+(& $encode ($powerBefore | ConvertTo-Json -Depth 12))+'</pre><h2>Power state after</h2><pre>'+(& $encode ($powerAfter | ConvertTo-Json -Depth 12))+'</pre>'
    $html+='<h2>Generated files</h2><ul>';foreach($f in $files){$html+='<li>'+(& $encode $f)+'</li>'};$html+='</ul><h2>Activity</h2><table><tr><th>Time</th><th>Level</th><th>Detail</th></tr>'
    foreach($e in $events){$html+='<tr><td>'+(& $encode $e.Time)+'</td><td class="'+(& $encode $e.Level)+'">'+(& $encode $e.Level)+'</td><td><pre>'+(& $encode $e.Message)+'</pre></td></tr>'}
    $html+='</table></body></html>'
    $report=Join-Path $dirs.Reports "$session.html"
    [IO.File]::WriteAllText($report,$html,(New-Object Text.UTF8Encoding($false)))
    Write-Host "Report: $report`nLog: $logPath"
}
try {
    Write-Host "`n==============================================================" -ForegroundColor Cyan
    Write-Host ' WINDOWS SCREEN SAVER REGISTRY CONFIGURATION GENERATOR' -ForegroundColor Cyan
    Write-Host "==============================================================`n" -ForegroundColor Cyan
    Log "Session $session started. PowerShell $($PSVersionTable.PSVersion)."
    $cfg=[ordered]@{SchemaVersion=1;ScreenSaver='None';WaitMinutes=10;RequireLogon=$true;TextMode='Custom';Message='Windows';PhotosDirectory='%USERPROFILE%\Pictures';PhotosCapturedDirectory=$null;PhotoSpeed='Medium';PhotoShuffle=$true;SaverValues=@();Power=[ordered]@{DisplayACMinutes=$null;DisplayDCMinutes=$null;SleepACMinutes=$null;SleepDCMinutes=$null;HibernateACMinutes=$null;HibernateDCMinutes=$null}}
    if($Setup){
        if($Configuration -or $Apply){throw '-Setup cannot be combined with -Configuration or -Apply.'}
        $target=if($SetupPath){$SetupPath}else{Join-Path $PSScriptRoot 'ScreenSaverConfig.default.json'}
        if(Test-Path -LiteralPath $target){throw "File already exists: $target. Use -SetupPath for a new filename."}
        $cfg | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $target -Encoding UTF8
        $files.Add([IO.Path]::GetFullPath($target));Log "Created default configuration: $target";$status='Setup completed';return
    }
    if($env:OS -ne 'Windows_NT'){throw 'Configuration generation and application require Windows. -Setup can run on other platforms.'}
    if(-not [Environment]::Is64BitProcess -and [Environment]::Is64BitOperatingSystem){throw 'Use 64-bit PowerShell to avoid redirected screen saver executables and registry keys.'}
    if([Security.Principal.WindowsIdentity]::GetCurrent().IsSystem){throw 'Run as the intended signed-in user, not SYSTEM.'}
    if($Configuration){
        $loaded=Get-Content -LiteralPath $Configuration -Raw | ConvertFrom-Json
        foreach($prop in $loaded.PSObject.Properties){
            if(-not $cfg.Contains($prop.Name)){throw "Unknown configuration field: $($prop.Name)"}
            if($prop.Name -eq 'Power'){
                foreach($pp in $prop.Value.PSObject.Properties){if(-not $cfg.Power.Contains($pp.Name)){throw "Unknown power field: $($pp.Name)"};$cfg.Power[$pp.Name]=$pp.Value}
            }else{$cfg[$prop.Name]=$prop.Value}
        }
        Log "Loaded configuration: $Configuration"
    }
    foreach($name in 'ScreenSaver','WaitMinutes','RequireLogon','TextMode','Message','PhotosDirectory','PhotoSpeed','PhotoShuffle') {if($bound.ContainsKey($name)){$cfg[$name]=$bound[$name]}}
    foreach($name in @($cfg.Power.Keys)){if($bound.ContainsKey($name)){$cfg.Power[$name]=$bound[$name]}}
    if($SaverValuesJson){$cfg.SaverValues=@(Get-Content -LiteralPath $SaverValuesJson -Raw | ConvertFrom-Json);Log "Loaded saver values: $SaverValuesJson"}
    $wizard=(-not $NonInteractive -and -not $Configuration -and -not $bound.ContainsKey('ScreenSaver'))
    if($wizard){$cfg.ScreenSaver=Choose 'Select the screen saver' @('None','3D Text','Blank','Pictures','Bubbles','Mystify','Photos','Ribbons')}
    if($cfg.SchemaVersion -ne 1){throw 'Unsupported configuration schema.'}
    if(@('None','3D Text','Blank','Pictures','Bubbles','Mystify','Photos','Ribbons') -notcontains $cfg.ScreenSaver){throw 'Invalid screen saver.'}
    if($cfg.ScreenSaver -eq 'Pictures'){Log 'Pictures maps to the modern Windows Photos screen saver.';$cfg.ScreenSaver='Photos'}
    $catalog=@{
        'None'=@{File=$null;Roots=@();Options='No screen saver. Wait/logon settings are stored but inactive.'}
        'Blank'=@{File='scrnsave.scr';Roots=@();Options='Blank has no screen saver-specific options.'}
        '3D Text'=@{File='ssText3d.scr';Roots=@('Software\Microsoft\Windows\CurrentVersion\Screensavers\ssText3d','Software\Microsoft\Screensavers\Text3D');Options='Text or time; font; size; resolution; rotation type and speed; surface style, color, texture and reflection: use the native Settings dialog.'}
        'Photos'=@{File='PhotoScreensaver.scr';Roots=@('Software\Microsoft\Windows Photo Viewer\Slideshow\Screensaver');Options='Photo folder, slide show speed, shuffle: use native Settings for the encoded folder selection.'}
        'Bubbles'=@{File='Bubbles.scr';Roots=@('Software\Microsoft\Windows\CurrentVersion\Screensavers\Bubbles');Options='Windows exposes no supported Settings controls. Existing advanced registry values can be captured or supplied using SaverValues.'}
        'Mystify'=@{File='Mystify.scr';Roots=@('Software\Microsoft\Windows\CurrentVersion\Screensavers\Mystify');Options='Windows exposes no supported Settings controls. Existing advanced registry values can be captured or supplied using SaverValues.'}
        'Ribbons'=@{File='Ribbons.scr';Roots=@('Software\Microsoft\Windows\CurrentVersion\Screensavers\Ribbons');Options='Windows exposes no supported Settings controls. Existing advanced registry values can be captured or supplied using SaverValues.'}
    }
    $entry=$catalog[$cfg.ScreenSaver];Log $entry.Options
    $exe=$null;if($entry.File){$exe=Join-Path "$env:SystemRoot\System32" $entry.File;if(-not(Test-Path -LiteralPath $exe)){throw "Selected screen saver is not installed: $exe"}}
    if($cfg.ScreenSaver -eq '3D Text' -and $wizard){
        $cfg.TextMode=Choose 'Display a custom message or the current time?' @('Custom','Time')
        if($cfg.TextMode -eq 'Custom') { do{$cfg.Message=Ask 'Custom message (maximum 20 characters)' $cfg.Message}while($cfg.Message.Length -gt 20) }
    }
    if($cfg.ScreenSaver -eq 'Photos'){
        if($wizard){$cfg.PhotosDirectory=Select-PhotosFolder}
        $cfg.PhotosDirectory=Validate-Folder $cfg.PhotosDirectory
        Log "Requested photo folder: $($cfg.PhotosDirectory)"
    }
    $capture=[bool]$NativeSettings
    if($wizard -and $entry.Roots.Count -gt 0 -and $cfg.ScreenSaver -ne 'Photos'){$capture=Yes 'Open native Settings and capture all current options?' $true}
    if($cfg.ScreenSaver -eq 'Photos'){
        $hasFolder=@($cfg.SaverValues | Where-Object {$_.Name -eq 'EncryptedPIDL'}).Count -gt 0
        if(-not $hasFolder){$capture=$true}
        if($hasFolder){
            if(-not $cfg.PhotosCapturedDirectory -or (Validate-Folder $cfg.PhotosCapturedDirectory) -ne $cfg.PhotosDirectory){
                Log 'Photo directory changed or has not been confirmed against captured settings; recapture required.' 'Warning'
                $capture=$true
            }
        }
        if($capture -and $NonInteractive){throw 'Photos needs a captured EncryptedPIDL. Run the interactive wizard once and reuse its saved JSON; no undocumented folder encoding is guessed.'}
        if($capture){
            Write-Host "In the Windows Photos Settings dialog, click Browse and select:`n$($cfg.PhotosDirectory)`nAlso choose speed and shuffle, then click Save."
            $null=Ask 'Press Enter to open Photos Settings'
        }
    }
    if($capture -and $entry.Roots.Count -gt 0){
        if($NonInteractive){throw '-NativeSettings requires an interactive session.'}
        $cfg.SaverValues=@(Native-Capture $exe $entry.Roots)
        if($cfg.ScreenSaver -eq 'Photos'){
            if(-not(Yes "Did you save Photos Settings with folder '$($cfg.PhotosDirectory)'?" $false)){throw 'Photo folder selection was not confirmed. No configuration applied.'}
            if(@($cfg.SaverValues | Where-Object {$_.Name -eq 'EncryptedPIDL'}).Count -eq 0){throw 'Photos did not save its folder value. Configure the Photos dialog and retry.'}
            $cfg.PhotosCapturedDirectory=$cfg.PhotosDirectory
            # Native speed/shuffle remain authoritative unless explicitly overridden.
            foreach($r in $cfg.SaverValues){
                if($r.Name -eq 'Shuffle' -and -not $bound.ContainsKey('PhotoShuffle')){$cfg.PhotoShuffle=([int]$r.Value -ne 0)}
                if($r.Name -eq 'Speed' -and -not $bound.ContainsKey('PhotoSpeed')){switch([int]$r.Value){0{$cfg.PhotoSpeed='Slow'}1{$cfg.PhotoSpeed='Medium'}2{$cfg.PhotoSpeed='Fast'}}}
            }
        }
    }elseif($wizard -and $entry.Roots.Count -gt 0 -and @($cfg.SaverValues).Count -eq 0){
        $cfg.SaverValues=@(foreach($root in $entry.Roots){(Snapshot $root).Values})
    }
    $cfg.SaverValues=@($cfg.SaverValues)
    if($cfg.ScreenSaver -eq '3D Text'){
        if($cfg.TextMode -notin @('Custom','Time') -or ([string]$cfg.Message).Length -gt 20){throw 'Invalid 3D text mode or message longer than 20 characters.'}
        $root='HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Screensavers\ssText3d'
        $cfg.SaverValues=@(Upsert $cfg.SaverValues (Row $root 'DisplayTime' 'DWord' ([int]($cfg.TextMode -eq 'Time'))))
        $cfg.SaverValues=@(Upsert $cfg.SaverValues (Row $root 'DisplayString' 'String' ([string]$cfg.Message)))
    }
    if($cfg.ScreenSaver -eq 'Photos'){
        if($cfg.PhotoSpeed -notin @('Slow','Medium','Fast') -or $cfg.PhotoShuffle -isnot [bool]){throw 'Invalid photo speed or shuffle value.'}
        $root='HKEY_CURRENT_USER\Software\Microsoft\Windows Photo Viewer\Slideshow\Screensaver'
        $cfg.SaverValues=@(Upsert $cfg.SaverValues (Row $root 'Speed' 'DWord' (@{Slow=0;Medium=1;Fast=2}[$cfg.PhotoSpeed])))
        $cfg.SaverValues=@(Upsert $cfg.SaverValues (Row $root 'Shuffle' 'DWord' ([int]$cfg.PhotoShuffle)))
    }
    Check-Values $cfg.SaverValues $entry.Roots
    if(@($cfg.SaverValues).Count -gt 0){Write-Host 'Saver-specific configuration:';$cfg.SaverValues | Format-Table -Property @('Name','Kind','Value') -Wrap | Out-Host}
    if($wizard){$cfg.WaitMinutes=Minutes 'Screen saver wait time in minutes' 10 1;$cfg.RequireLogon=Yes 'On resume, display logon screen?' $true}
    if($cfg.WaitMinutes -isnot [int] -and $cfg.WaitMinutes -isnot [long]){throw 'WaitMinutes must be an integer.'}
    if($cfg.WaitMinutes -lt 1 -or $cfg.WaitMinutes -gt 9999 -or $cfg.RequireLogon -isnot [bool]){throw 'Invalid wait time or RequireLogon (must be true/false).'}
    foreach($policy in 'HKCU:\Software\Policies\Microsoft\Windows\Control Panel\Desktop','HKLM:\Software\Policies\Microsoft\Windows\Control Panel\Desktop'){
        if(Test-Path $policy){Log "Policy key exists: $policy. Managed policy may override these preferences; policies will not be changed." 'Warning'}
    }
    $active=Run-Power @('/getactivescheme');$match=[regex]::Match($active,'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}')
    if(-not $match.Success){throw 'Cannot determine active power plan.'};$scheme=$match.Value
    $definitions=@(
        @{Name='Display';Sub='7516b95f-f776-4464-8c53-06167f40cc99';Setting='3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e'},
        @{Name='Sleep';Sub='238c9fa8-0aad-41ed-83f4-97be242c8f20';Setting='29f6c1db-86da-48c5-9fdb-f2b67b1f44da'},
        @{Name='Hibernate';Sub='238c9fa8-0aad-41ed-83f4-97be242c8f20';Setting='9d7815a6-7ee4-497e-8888-515a05f02364'}
    )
    Log (Run-Power @('/a'))
    $changes=@()
    foreach($def in $definitions){
        try { $indices=Read-Setting $def.Sub $def.Setting } catch {
            Log "Cannot inspect $($def.Name) timer on this hardware: $($_.Exception.Message)" 'Warning'
            foreach($source in 'AC','DC'){
                $field=$def.Name+$source+'Minutes'
                if($null -ne $cfg.Power[$field]){throw "Cannot configure unsupported/unreadable timer: $field"}
                $powerBefore+=[pscustomobject]@{Type=$def.Name;Source=$source;Seconds='Unavailable';Plan=$scheme}
            }
            continue
        }
        foreach($source in 'AC','DC'){
            $field=$def.Name+$source+'Minutes';$old=[long]$indices[$source];$desired=$cfg.Power[$field]
            $powerBefore+= [pscustomobject]@{Type=$def.Name;Source=$source;Seconds=$old;Plan=$scheme}
            if($null -ne $desired){
                if(($desired -isnot [int] -and $desired -isnot [long]) -or $desired -lt 0 -or $desired -gt 35791394){throw "$field must be a whole number from 0 to 35791394, or null to preserve."}
                $seconds=[long]$desired*60
            }else{$seconds=$old}
            $conflict=($cfg.ScreenSaver -ne 'None' -and $seconds -gt 0 -and $seconds -le ([long]$cfg.WaitMinutes*60))
            if($conflict){
                $sourceLabel=if($source -eq 'AC'){'plugged in'}else{'on battery'}
                Log "$($def.Name) $sourceLabel occurs after $seconds seconds, at/before the screen saver ($($cfg.WaitMinutes) minutes)." 'Warning'
                if($NonInteractive){throw "Power conflict: supply -$field with 0 (Never) or a timeout greater than WaitMinutes."}
                $action=Choose "Resolve $($def.Name) timer ($sourceLabel)" @('Never: disable this idle timer','Set idle minutes','Keep current/requested timer (screen saver may not run)')
                switch -Wildcard($action){
                    'Never*'{$seconds=0;$cfg.Power[$field]=0}
                    'Set*'{do{$n=Minutes "$($def.Name) idle minutes (0 = Never; otherwise greater than $($cfg.WaitMinutes))" ($cfg.WaitMinutes+5)}while($n -ne 0 -and $n -le $cfg.WaitMinutes);$seconds=[long]$n*60;$cfg.Power[$field]=$n}
                    default{Log "User accepted unresolved $field conflict." 'Warning'}
                }
            }
            if($seconds -ne $old){$changes+=[pscustomobject]@{Type=$def.Name;Source=$source;Sub=$def.Sub;Setting=$def.Setting;Old=$old;New=$seconds}}
        }
    }
    $desktop='HKEY_CURRENT_USER\Control Panel\Desktop'
    $screenRows=@((Row $desktop 'ScreenSaveActive' 'String' $(if($cfg.ScreenSaver -eq 'None'){'0'}else{'1'})),(Row $desktop 'ScreenSaveTimeOut' 'String' ([string]([long]$cfg.WaitMinutes*60))),(Row $desktop 'ScreenSaverIsSecure' 'String' ([string][int]$cfg.RequireLogon)))
    if($cfg.ScreenSaver -eq 'None'){$screenRows+=Row $desktop 'SCRNSAVE.EXE' 'Delete' $null}else{$screenRows+=Row $desktop 'SCRNSAVE.EXE' 'String' $exe}
    $screenRows+=@($cfg.SaverValues)
    $powerRows=@();$powerRestore=@()
    foreach($c in $changes){
        $path="HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\$scheme\$($c.Sub)\$($c.Setting)"
        $powerRows+=Row $path ($c.Source+'SettingIndex') 'DWord' $c.New
        # Restore the effective old plan setting, even if its original backing value was inherited.
        $powerRestore+=Row $path ($c.Source+'SettingIndex') 'DWord' $c.Old
    }
    Write-Host "`nReady to generate commented registry files. Saver: $($cfg.ScreenSaver); wait: $($cfg.WaitMinutes) min; logon: $($cfg.RequireLogon)."
    $changes | Format-Table -Property @('Type','Source','Old','New') -AutoSize | Out-Host
    Write-Host 'Power values above are seconds; 0 means Never. No hibernation feature, critical-battery action, policy, or unattended-sleep setting is changed.'
    if(-not $NonInteractive -and -not(Yes 'Continue and generate configuration files?' $true)){$status='Cancelled before generation';return}
    $prefix=Join-Path $dirs.RegFiles $session
    $screenFile="$prefix.ScreenSaver.reg";$powerFile="$prefix.Power.reg";$screenUndo="$prefix.ScreenSaver.Restore.reg";$powerUndo="$prefix.Power.Restore.reg"
    $notes=@("Generated $session on $hostNameSafe for $env:USERDOMAIN\$env:USERNAME.",'Review before importing. Screen saver preferences apply only to the importing user.','ScreenSaveTimeOut is seconds. ScreenSaveActive: 1=enabled, 0=disabled.','ScreenSaverIsSecure: 1=show logon on resume, 0=no screen saver logon requirement.','None removes SCRNSAVE.EXE. Saver-specific values preserve their native registry types.','This file does not enforce policy. Domain/MDM policy can override preferences.','Use the matching Restore file to undo values. Sign out/in after a manual import if needed.')
    Write-Reg $screenFile $screenRows $notes
    $screenPrior=@(foreach($r in $screenRows){Prior-Row $r})
    Write-Reg $screenUndo $screenPrior @('Restore values observed before generation. Newly introduced values are deleted.','Only the importing user is affected. Sign out/in to refresh. Empty keys may remain.')
    $powerNotes=@("Active plan at generation: $scheme. Machine-specific; do not use on a different computer/plan.",'ACSettingIndex=plugged in. DCSettingIndex=battery. All values are seconds; 0=Never.','Only changed display/sleep/hibernate idle timers are included. No policy is written.','Administrator rights are required to import power changes.','Windows caches power settings. Use this script -Apply (powercfg), or reactivate this plan after manual import:',"powercfg /setactive $scheme",'The Power.Restore.reg file restores effective prior timer values; reactivate the plan after importing it.')
    Write-Reg $powerFile $powerRows $powerNotes
    Write-Reg $powerUndo $powerRestore @('Restore effective prior power timer values. Administrator rights required.',"After importing, run: powercfg /setactive $scheme")
    $saved="$prefix.Configuration.json";$cfg | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $saved -Encoding UTF8;$files.Add($saved)
    Log "Saved reusable configuration $saved"
    $applyNow=[bool]$Apply
    if(-not $NonInteractive -and -not $applyNow){$applyNow=Yes 'Apply the generated screen saver and power configuration now?' $false}
    if(-not $applyNow){$status='Generated; not applied';return}
    $admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if($changes.Count -gt 0 -and -not $admin){throw 'Files generated, but no settings applied. Power changes require an elevated PowerShell session under this SAME user. Run with -Configuration <saved JSON> -NonInteractive -Apply from that session.'}
    $current=Run-Power @('/getactivescheme');if($current -notmatch [regex]::Escape($scheme)){throw 'Active plan changed during the wizard. Run again; no changes applied.'}
    try{
        Import-Reg $screenFile
        # Use supported powercfg API instead of relying on raw registry imports.
        foreach($c in $changes){$null=Run-Power @($(if($c.Source -eq 'AC'){'/setacvalueindex'}else{'/setdcvalueindex'}),$scheme,$c.Sub,$c.Setting,[string]$c.New)}
        if($changes.Count -gt 0){$null=Run-Power @('/setactive',$scheme)}
        foreach($r in $screenRows){
            $actual=Prior-Row $r
            if(($actual | ConvertTo-Json -Compress -Depth 20) -ne ($r | ConvertTo-Json -Compress -Depth 20)){
                # DWord values may be returned signed; compare import representation instead.
                if((Reg-Line $actual) -ne (Reg-Line $r)){throw "Registry verification failed: $($r.Path) / $($r.Name)"}
            }
        }
        foreach($def in $definitions){
            if(@($powerBefore | Where-Object {$_.Type -eq $def.Name -and $_.Seconds -eq 'Unavailable'}).Count -gt 0){continue}
            $indices=Read-Setting $def.Sub $def.Setting
            foreach($source in 'AC','DC'){$powerAfter+=[pscustomobject]@{Type=$def.Name;Source=$source;Seconds=$indices[$source];Plan=$scheme}}
        }
        foreach($c in $changes){$actual=@($powerAfter | Where-Object {$_.Type -eq $c.Type -and $_.Source -eq $c.Source})[0].Seconds;if($actual -ne $c.New){throw "Power verification failed: $($c.Type) $($c.Source)"}}
        Log 'Registry and effective power plan values verified.'
    }catch{
        Log "Apply failed; attempting rollback: $($_.Exception.Message)" 'Error'
        try{Import-Reg $screenUndo;foreach($c in $changes){$null=Run-Power @($(if($c.Source -eq 'AC'){'/setacvalueindex'}else{'/setdcvalueindex'}),$scheme,$c.Sub,$c.Setting,[string]$c.Old)};if($changes.Count -gt 0){$null=Run-Power @('/setactive',$scheme)};Log 'Rollback completed.' 'Warning'}catch{Log "Rollback failed; use Restore files: $($_.Exception.Message)" 'Error'}
        throw
    }
    # Supported user32 calls update the running session without launching the saver.
    try {
    if(-not ('ScreenSaverGenerator.Native' -as [type])){
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace ScreenSaverGenerator {
 public static class Native {
  [DllImport("user32.dll", SetLastError=true)]
  [return: MarshalAs(UnmanagedType.Bool)]
  public static extern bool SystemParametersInfo(uint action, uint param, IntPtr value, uint flags);
 }
}
'@
    }
    $refresh=$true
    foreach($pair in @(@(0x0011,[uint32]($cfg.WaitMinutes*60)),@(0x0077,[uint32][int]$cfg.RequireLogon),@(0x0017,[uint32][int]($cfg.ScreenSaver -ne 'None')))){
        if(-not [ScreenSaverGenerator.Native]::SystemParametersInfo($pair[0],$pair[1],[IntPtr]::Zero,3)){$refresh=$false}
    }
    if(-not $refresh){Log 'Some session refresh calls failed. Sign out and back in to load the saved preferences.' 'Warning'}
    }catch{Log "Session refresh failed: $($_.Exception.Message). Sign out and back in to load saved preferences." 'Warning'}
    $status='Applied and verified';Log 'Configuration applied. Test your selected saver and its idle activation on this PC; Modern Standby, policy and application power requests can affect behavior.'
}catch{
    $status='Failed';Log $_.Exception.ToString() 'Error';throw
}finally{
    Log "Session ended: $status"
    Write-Report
}
